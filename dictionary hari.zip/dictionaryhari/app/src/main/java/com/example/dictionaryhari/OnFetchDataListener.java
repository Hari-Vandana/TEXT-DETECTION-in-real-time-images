package com.example.dictionaryhari;

import com.example.dictionaryhari.Models.APIResponse;

public class OnFetchDataListener {
    void onFetchData(APIResponse apiResponse, String message);
    void onError(String message);
}
