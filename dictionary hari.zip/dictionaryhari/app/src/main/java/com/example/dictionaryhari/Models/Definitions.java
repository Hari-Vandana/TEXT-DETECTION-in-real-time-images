package com.example.dictionaryhari.Models;

public class Definitions {
    String definition = "";
    String example = "";

    public String getDefinition() {
        return definition;
    }

    public void setDefinition(String definition) {
        this.definition = definition;
    }

    public String getExample() {
        return example;
    }

    public void setExample(String example) {
        this.example = example;
    }
}
